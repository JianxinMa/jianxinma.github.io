The script will download and put datasets in this directory.
